import React from 'react';
import { Container, Row, Col } from 'reactstrap';

function Links() {
    return (
        <Container fluid>
            <Row>
                {/* <Col md={9}>
                </Col> */}
                <Col md={3}>
                    {/* Links here */}
                    <div className="d-flex flex-column">
                        <a href="/">Home</a>
                        <a href="/directory">Directory</a>
                        <a href="/aboutus">About Us</a>
                        <a href="/contact">Contact</a>
                    </div>
                </Col>
            </Row>
        </Container>
    );
}

export default Links;
