import { Navbar, NavbarBrand } from 'reactstrap';
import NucampLogo from '../app/assets/img/logo.png';
import { Container, Row, Col } from 'reactstrap';

const Header = () => {
    return (
        <Navbar dark color='primary' sticky='top' expand='md'>
            <Container fluid>
            <Row>
                <Col md={9}>
                    
                    <NavbarBrand href='/'>
                        <img src={NucampLogo} alt='nucamp logo' />
                    </NavbarBrand>
                </Col>
                <Col md={3}>
                    {/* Links here */}
                    <div className="d-flex align-items-start justify-content-around flex-row">
                        <NavbarBrand href="/" className="mx-2">Home</NavbarBrand>
                        <NavbarBrand href="/directory" className="mx-2">Directory</NavbarBrand>
                        <NavbarBrand href="/aboutus" className="mx-2">About Us</NavbarBrand>
                        <NavbarBrand href="/contact" className="mx-2">Contact</NavbarBrand>
                    </div>
                </Col>
            </Row>
        </Container>
        </Navbar>
    );
};

export default Header;
