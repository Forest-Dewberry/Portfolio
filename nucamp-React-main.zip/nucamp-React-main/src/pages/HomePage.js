import CampsitesList from '../features/campsites/CampsitesList';

const HomePage = () => {
    return (
        <>
            <CampsitesList />
        </>
    );
};

export default HomePage;
