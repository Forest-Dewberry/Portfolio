// src/pages/CampsiteDetailPage.js
import React from 'react';
import { useParams } from 'react-router-dom';
import { CAMPSITES } from '../app/shared/CAMPSITES'; // Adjusted the import path
import { Container, Row } from 'reactstrap';

function CampsiteDetailPage() {
  const { campsiteId } = useParams();
  const campsite = CAMPSITES.find(c => c.id === parseInt(campsiteId));

  // If no campsite found, render a message or redirect, etc.
  if (!campsite) {
    return <div>No campsite found!</div>;
  }

  return (
    <Container>
        <Row>
            <h1>{campsite.name}</h1>
        </Row>
        <Row>
            <img src={campsite.image} alt={campsite.name} />
        </Row>
        <Row>
            <p>{campsite.description}</p>
        </Row>
    </Container>
  );
}

export default CampsiteDetailPage;
