
Use:

### `npm ci`

to clean install the node_modules folder in any branch. Clean install means it will use the existing package-lock.json file and won't alter it.

Use:

### `git switch <branchname>`

To checkout and switch to a branch.